#include <stdio.h>
#include "fatorial.h"

int main() {
  int n = fatorial(5);
  printf("5! = %d\n",n);
  return 0;
}
