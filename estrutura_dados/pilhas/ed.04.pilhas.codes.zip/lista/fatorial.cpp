#include <iostream>
#include "fatorial.hpp"

using namespace std;

int main() {
  int n = fatorial(5);
  cout << "5! = " << n << endl;
  return 0;
}
